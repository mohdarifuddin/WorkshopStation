package voyanta.ui.pageobjects;

import org.openqa.selenium.WebElement;

/**
 * Created by sriramangajala on 24/07/2014.
 */
public interface PageContainer {


    public WebElement getDefaultElement();

    public WebElement getHeaderElement();

}
