package voyanta.ui.pageobjects;

/**
 * Created by sriramangajala on 07/08/2014.
 */
public class ListOfMappingRulesPage {
}
